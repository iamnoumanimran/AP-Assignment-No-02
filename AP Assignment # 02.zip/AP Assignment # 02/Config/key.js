module.exports={
      MongoURI: 'mongodb+srv://Nouman:Nomiking5482@cluster0-asdku.mongodb.net/test?retryWrites=true&w=majority'
}